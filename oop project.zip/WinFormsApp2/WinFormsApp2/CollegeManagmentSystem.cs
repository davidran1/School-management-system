﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using person;
using System.Media;

namespace WinFormsApp2
{
    public partial class CollegeManagmentSystem : Form
    {
       private  List<Person> personList = new List<Person>();
        public CollegeManagmentSystem()
        {
            InitializeComponent();

        }

        private void CollegeManagmentSystem_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)//graduate students
        {
            graduatedStudentsData g = new graduatedStudentsData();
            for(int i =0;i<personList.Count;i++) 
            {
                if (personList[i].GetType() == typeof(GraduateSudent))
                {
                   GraduateSudent graduate = (GraduateSudent)personList[i];
                    g.graduatedStudentsList.Add(graduate);
                }
            }
            if(g.graduatedStudentsList.Count==0)
            {
                MessageBox.Show("There is no graduated students!");
            }
            else
            {
                g.Show();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (PersonTypeComboBox.Text == "Student")
            {
                firstNameLabel.Visible = true;
                lastNameLabel.Visible = true;
                firstNameTxtBox.Visible = true;
                lastNameTxtbox.Visible = true;
                idLabel.Visible = true;
                idTxtBox.Visible = true;
                ageLabel.Visible = true;
                ageTextBox.Visible = true;
                malePictureBox.Visible = true;
                ganderLabel.Visible = true;
                femalePictureBox.Visible = true;
                yearEducationLabel.Visible = true;
                yearEducationLabel.Text = "year";
                yearEducationTxtBox.Visible = true;
                averageLabel.Visible = true;
                averageTxtBox.Visible = true;
                addButton.Visible = true;
                updateButton.Visible = true;
                deleteButton.Visible = true;
                maleSelectedButton.Visible = true;
                femaleSelectedButton.Visible = true;
                this.yearEducationTxtBox.Items.Clear();
                this.yearEducationTxtBox.Items.AddRange(new object[] {
                "1",
                "2",
                "3",
                "4",
                "Done"});
            }
            else if (PersonTypeComboBox.Text == "Lecturer")
            {
                firstNameLabel.Visible = true;
                lastNameLabel.Visible = true;
                firstNameTxtBox.Visible = true;
                lastNameTxtbox.Visible = true;
                idLabel.Visible = true;
                idTxtBox.Visible = true;
                ageLabel.Visible = true;
                ageTextBox.Visible = true;
                malePictureBox.Visible = true;
                ganderLabel.Visible = true;
                femalePictureBox.Visible = true;
                yearEducationLabel.Visible = true;
                yearEducationLabel.Text = "education";
                yearEducationTxtBox.Visible = true;
                averageLabel.Visible = false;
                averageTxtBox.Visible = false;
                addButton.Visible = true;
                updateButton.Visible = true;
                deleteButton.Visible = true;
                maleSelectedButton.Visible = true;
                femaleSelectedButton.Visible = true;
                this.yearEducationTxtBox.Items.Clear();
                this.yearEducationTxtBox.Items.AddRange(new object[] {
                "Associate",
                "Bachelor's",
                "Master's",
                "Doctoral"});

            }
            else if (PersonTypeComboBox.Text == "Choose..")
            {
                firstNameLabel.Visible = false;
                lastNameLabel.Visible = false;
                firstNameTxtBox.Visible = false;
                lastNameTxtbox.Visible = false;
                idLabel.Visible = false;
                idTxtBox.Visible = false;
                ageLabel.Visible = false;
                ageTextBox.Visible = false;
                malePictureBox.Visible = false;
                ganderLabel.Visible = false;
                femalePictureBox.Visible = false;
                yearEducationLabel.Visible = false;
                yearEducationTxtBox.Visible = false;
                averageLabel.Visible = false;
                averageTxtBox.Visible = false;
                addButton.Visible = false;
                updateButton.Visible = false;
                deleteButton.Visible = false;
                maleSelectedButton.Visible = false;
                femaleSelectedButton.Visible = false;
            }
        }

        private void nameLabel_Click(object sender, EventArgs e)
        {

        }

        private void ageTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (PersonTypeComboBox.Text == "Student")
            {
                if (firstNameTxtBox.Text != "" && lastNameTxtbox.Text != "" && idTxtBox.Text != "" && ageTextBox.Text != "" && (maleSelectedButton.Checked || femaleSelectedButton.Checked)
                    && yearEducationTxtBox.Text != "" && averageTxtBox.Text != "")
                {
                    String name = firstNameTxtBox.Text + " " + lastNameTxtbox.Text;
                    String id = idTxtBox.Text;
                    int age = int.Parse(ageTextBox.Text);
                    int Year = int.Parse(yearEducationTxtBox.Text);
                    double avr = double.Parse(averageTxtBox.Text);
                    for (int i = 0; i < personList.Count; i++)
                        {
                            if (id == personList[i].getId())
                            {
                                MessageBox.Show("Already exist in system");
                                return;
                            }
                        }
                    if (maleSelectedButton.Checked)
                    {
                        Person person = new ActiveStudent(name, "Male", id, age, Year, avr);
                        personList.Add(person);
                        MessageBox.Show("Succssefully added");
                    }
                    else if (femaleSelectedButton.Checked)
                    {
                        Person person = new ActiveStudent(name, "Female", id, age, Year, avr);
                        personList.Add(person);
                        MessageBox.Show("Succssefully added");
                    }
                }
                else
                {
                    MessageBox.Show("Pls fill all the fields!");
                }

            }
            else if (PersonTypeComboBox.Text == "Lecturer")
            {
                if (firstNameTxtBox.Text != "" && lastNameTxtbox.Text != "" && idTxtBox.Text != "" && ageTextBox.Text != "" && (maleSelectedButton.Checked || femaleSelectedButton.Checked)
              && yearEducationTxtBox.Text != "" )
                {
                    String name = firstNameTxtBox.Text + " " + lastNameTxtbox.Text;
                    String id = idTxtBox.Text;
                    int age = int.Parse(ageTextBox.Text);
                    String education = (yearEducationTxtBox.Text);
                    if (maleSelectedButton.Checked)
                    {
                        Person person = new Lecturer(name, "Male", id, age, education);
                        personList.Add(person);
                    }
                    else if (femaleSelectedButton.Checked)
                    {
                        Person person = new Lecturer(name, "Female", id, age, education);
                        personList.Add(person);
                    }
                    MessageBox.Show("Succssefully added");
                }
                else
                {
                    MessageBox.Show("Pls fill all the fields!");
                }
            }
            else
            {
                MessageBox.Show("Pls select type and fill all the fields!");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)//active students
        {
            activeStudentsData s = new activeStudentsData();
            for(int i=0;i<personList.Count;i++)
            {
                if (personList[i].GetType() == typeof(ActiveStudent))
                {
                    ActiveStudent a = (ActiveStudent)personList[i];
                    s.activeStudentsList.Add(a);
                }
            }
            if (s.activeStudentsList.Count == 0)
            {
                MessageBox.Show("There is no active students!");
            }
            else
            {
                s.Show();
            }   
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            int flag = 0;
            for (int i = 0; i < personList.Count; i++)
            {
                if (personList[i].getId() == idTxtBox.Text)
                {
                    personList.Remove(personList[i]);
                    MessageBox.Show("succssefully deleted");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
            {
                MessageBox.Show("FAILED-ID not found in the system");
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (PersonTypeComboBox.Text == "Student")
            {
                if (firstNameTxtBox.Text != "" && lastNameTxtbox.Text != "" && idTxtBox.Text != "" && ageTextBox.Text != "" && (maleSelectedButton.Checked || femaleSelectedButton.Checked)
                    && yearEducationTxtBox.Text != "" && averageTxtBox.Text != "")
                {
                    int flag = 0;
                    for (int i = 0; i < personList.Count; i++)
                    {
                        if (personList[i].getId() == idTxtBox.Text)//use setters
                        {
                            if(yearEducationTxtBox.Text =="Done")
                            {
                                String name = firstNameTxtBox.Text + " " + lastNameTxtbox.Text;
                                String id = idTxtBox.Text;
                                int age = int.Parse(ageTextBox.Text);
                                double finalAvr = (double.Parse(averageTxtBox.Text));
                                if(maleSelectedButton.Checked)
                                {
                                    GraduateSudent g = new GraduateSudent(name,"Male", id, age, finalAvr);
                                    personList.Add(g);
                                    personList.RemoveAt(i);
                                    SoundPlayer soundPlayer = new SoundPlayer(@"C:\temp\done.wav");
                                    soundPlayer.Play();
                                    MessageBox.Show("Succssefully updated!");
                                    return;
                                }
                                else
                                {
                                    GraduateSudent g = new GraduateSudent(name, "Female", id, age, finalAvr);
                                    personList.Add(g);
                                    personList.RemoveAt(i);
                                    SoundPlayer soundPlayer = new SoundPlayer(@"C:\temp\done");
                                    soundPlayer.Play();
                                    MessageBox.Show("Succssefully updated!");
                                    return;
                                } 
                            }
                            else
                            {
                                ActiveStudent s = (ActiveStudent)personList[i];
                                s.setName(firstNameTxtBox.Text + " " + lastNameTxtbox.Text);
                                s.setAge(int.Parse(ageTextBox.Text));
                                s.setCurrYear(int.Parse(yearEducationTxtBox.Text));
                                s.setCurrAvr(double.Parse(averageTxtBox.Text));
                                if (maleSelectedButton.Checked)
                                    s.setGander("Male");
                                else
                                {
                                    s.setGander("Female");
                                }
                                MessageBox.Show("succssefully updated");
                                flag = 1;
                                break;
                            }
                        }
                    }
                    if (flag == 0)
                    {
                        MessageBox.Show("FAILED-ID not found in the system");
                    }
                }
                else
                {
                    MessageBox.Show("Pls fill all the fields!");
                }
            }
            else if (PersonTypeComboBox.Text == "Lecturer")
            {
                if (firstNameTxtBox.Text != "" && lastNameTxtbox.Text != "" && idTxtBox.Text != "" && ageTextBox.Text != "" && (maleSelectedButton.Checked || femaleSelectedButton.Checked)
                       && yearEducationTxtBox.Text != "")
                {
                    int flag = 0;
                    for (int i = 0; i < personList.Count; i++)
                    {
                        if (personList[i].getId() == idTxtBox.Text)//use setters
                        {
                            personList[i].setName(firstNameTxtBox.Text + " " + lastNameTxtbox.Text);
                            personList[i].setAge(int.Parse(ageTextBox.Text));
                            if (maleSelectedButton.Checked)
                                personList[i].setGander("Male");
                            else
                            {
                                personList[i].setGander("Female");
                            }
                            MessageBox.Show("succssefully updated");
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 0)
                    {
                        MessageBox.Show("FAILED-ID not found in the system");
                    }
                }
                else
                {
                    MessageBox.Show("Pls fill all the fields!");
                }
            }
        }

        private void lecturersBox_Click(object sender, EventArgs e)
        {
            LecturersData l =new LecturersData();
            for(int i=0;i<personList.Count;i++)
            {
                if (personList[i].GetType() ==typeof(Lecturer))
                {
                   Lecturer lecturer = (Lecturer)personList[i];
                   l.lecturersList.Add(lecturer);
                }
            }
            if(l.lecturersList.Count == 0)
            {
                MessageBox.Show("There is no lecturers!");
            }
            else
            {
                l.Show();
            }
           
        }

        private void dashboardBox_Click(object sender, EventArgs e)
        {
            dashBoard d = new dashBoard();
            double totalActiveGrades = 0;
            double totalActiveAges = 0;
            double totalGraduateGrades = 0;
            double totalGraduateAges = 0;

            foreach (Person person in personList)
            {
                d.totalPersons++;
                if(person.getGander()=="Male")
                {
                    d.totalMales++;
                }
                else
                {
                    d.totalFemales++;
                }
                if (typeof(ActiveStudent) == person.GetType())
                {
                    ActiveStudent a = (ActiveStudent)person;
                    d.totalActiveStudens++;
                    if (a.getGander() == "Male")
                    {
                        d.totalActiveStudensMales++;
                    }
                    else
                    {
                        d.totalActiveStudensFemales++;
                    }
                    totalActiveGrades += a.getCurrAvr();
                    totalActiveAges += a.getAge();
                    d.totalActiveStudensAvr = (totalActiveGrades / d.totalActiveStudens);
                    d.totalActiveStudensAge = (totalActiveAges / d.totalActiveStudens);
                }
                else if (typeof(GraduateSudent) == person.GetType())
                {
                    GraduateSudent g = (GraduateSudent)person;
                    d.totalGraduatedStudens++;
                    if (g.getGander() == "Male")
                    {
                        d.totalGraduatedStudensMales++;
                    }
                    else
                    {
                        d.totalGraduatedStudensFemales++;
                    }
                    totalGraduateGrades += g.getAverage();
                    totalGraduateAges += g.getAge();
                    d.totalGraduatedStudensAvr = (totalGraduateGrades / d.totalGraduatedStudens);
                    d.totalGraduatedStudensAge= (totalGraduateAges/d.totalGraduatedStudens);
                }   
                else if(typeof(Lecturer)== person.GetType()) 
                {
                    Lecturer l = (Lecturer)person;
                    d.totalLecturers++;
                    if(l.getGander()=="Male")
                    {
                        d.totalMaleLectures++;
                    }
                    else
                    {
                        d.totalFemaleLectures++;
                    }
                }
            }
            d.Show();
           
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory=Directory.GetCurrentDirectory();
            saveFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            if(saveFileDialog1.ShowDialog()==DialogResult.OK)
            {
                IFormatter formatter = new BinaryFormatter();
                using(Stream stream = new FileStream(saveFileDialog1.FileName,FileMode.Create,FileAccess.Write,FileShare.None)) 
                {
                    formatter.Serialize(stream, personList);
                }
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            { 
                Stream stream =File.Open(openFileDialog1.FileName,FileMode.Open);
                var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                personList =(List<Person>)binaryFormatter.Deserialize(stream);
            }

        }

        private void yearEducationTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void averageTxtBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
