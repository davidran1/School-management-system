﻿using person;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class graduatedStudentsData : Form
    {
        public List <GraduateSudent>graduatedStudentsList = new List<GraduateSudent>();
        public graduatedStudentsData()
        {
            InitializeComponent();
        }

        private void graduatedStudentsData_Load(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Id", typeof(string));
            table.Columns.Add("Age", typeof(int));
            table.Columns.Add("Average", typeof(double));
            for(int i=0;i<graduatedStudentsList.Count;i++) 
            {
                table.Rows.Add(graduatedStudentsList[i].getName(), graduatedStudentsList[i].getId(), graduatedStudentsList[i].getAge(), graduatedStudentsList[i].getAverage());
            }
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
