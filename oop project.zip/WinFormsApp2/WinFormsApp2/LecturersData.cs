﻿using person;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class LecturersData : Form
    {
       public List<Lecturer> lecturersList = new List<Lecturer>();
        public LecturersData()
        {
            InitializeComponent();
        }

        private void LecturersData_Load(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Id", typeof(string));
            table.Columns.Add("Age", typeof(int));
            table.Columns.Add("Education", typeof(string));
            for(int i=0;i<lecturersList.Count;i++) 
            {
                table.Rows.Add(lecturersList[i].getName(), lecturersList[i].getId(), lecturersList[i].getAge(), lecturersList[i].getEducation());
            }
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
