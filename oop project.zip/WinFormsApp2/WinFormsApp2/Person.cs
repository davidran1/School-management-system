﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace person
{

    [Serializable]
    public abstract class Person
    {
        protected string _name;
        protected string _gander;
        protected string _id;
        protected int _age;
   
        public string getName()
        {
            return this._name;
        }

        public string getId()
        {
            return this._id;
        }
        public int getAge()
        {
            return this._age;
        }
        public string getGander()
        {
            return this._gander;
        }
        public void setName(String n)
        {
            this._name = n;
        }
        public void setId(String id) 
        { 
            this._id = id;
        }
        public void setAge(int age)
        {
            this._age = age;
        }
        public void setGander(String gander)
        {
            this._gander = gander;
        }
    }

    [Serializable]
    public class Student: Person
    {
        protected string _studentId;
        public Student(string _name, string _gander , string _id  , int _age )
        {
            this._name = _name;
            this._gander = _gander;
            this._id = _id;  
            this._age = _age;
            this._studentId = "1";
        }
        public void setStudentId(String studentId)
        {
            this._studentId = studentId;
        }
    }

    [Serializable]
    public class Lecturer : Person
    {
        protected String _lecturerId;
        protected String _education;
        public Lecturer(string _name, string _gander, string _id, int _age, string _education)
        {
            this._name = _name;
            this._gander = _gander;
            this._id = _id;
            this._age = _age;
            this._lecturerId ="2";
            this._education = _education;
        }
        public void setLecturerId(String lecturerId)
        { 
            this._lecturerId=lecturerId;
        }
        public void setEducation(String education)
        {
            this._education = education;
        }
        public String getEducation()
        {
            return this._education;
        }

    }
    [Serializable]
    public class ActiveStudent : Student
    {
        protected int _currYear;
        protected double _currAvr;
        public ActiveStudent(string _name, string _gander, string _id, int _age,int _currYear , double _currAvr):base(_name,_gander,_id, _age)
        {
            this._currAvr= _currAvr;
            this._currYear = _currYear;
            this._studentId = "3";
        }
        public double getCurrAvr() { return _currAvr; }
       public int getCurrYear() { return _currYear;}

        public void setCurrYear(int currYear) 
        {
            this._currYear= currYear;
        }
        public void setCurrAvr(double currAvr)
        {
            this._currAvr= currAvr;
        }
    }

    [Serializable]
    public class GraduateSudent : Student
    {
        protected double _finalAvr;
        public GraduateSudent(string _name, string _gander, string _id, int _age, double _finalAvr) : base(_name, _gander, _id, _age)
        {
            this._finalAvr = _finalAvr;
            this._studentId = "4";
        }
        public void setFinalAvr(double currAvr) 
        {
            this._finalAvr= currAvr;
        }
        public double getAverage()
        { return _finalAvr; }
    }

    [Serializable]
    public class  PersonsList
    {
        public List<Person> _personsList;

        public PersonsList()
        {
            this._personsList = new List<Person>();
        }
        public int counter()
        {
             return _personsList.Count;
            
        }

        public void Add(Person p)
        {
            _personsList.Add(p);
        }
        public void Remove(Person p)
        {
            _personsList.Remove(p);
        }

        //public Person this[int index]
        //{
        //    get
        //    {
        //        if (index >= _personsList.Count)
        //            return (Person)null;
        //        //SortedList internal method
        //        return (Person)_personsList.GetByIndex(index);
        //    }
        //    set
        //    {
        //        if (index <= _personsList.Count)
        //            _personsList[index] = value; //!!!		
        //    }
        //}
    }

}

