﻿namespace WinFormsApp2
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxUserName = new System.Windows.Forms.TextBox();
            this.textBoxPSWRD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BTNlogin = new System.Windows.Forms.Button();
            this.BTNreset = new System.Windows.Forms.Button();
            this.BTNshowPswrd = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxUserName
            // 
            this.textBoxUserName.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBoxUserName.Location = new System.Drawing.Point(337, 143);
            this.textBoxUserName.Name = "textBoxUserName";
            this.textBoxUserName.Size = new System.Drawing.Size(222, 32);
            this.textBoxUserName.TabIndex = 0;
            this.textBoxUserName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBoxPSWRD
            // 
            this.textBoxPSWRD.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBoxPSWRD.Location = new System.Drawing.Point(337, 229);
            this.textBoxPSWRD.Name = "textBoxPSWRD";
            this.textBoxPSWRD.Size = new System.Drawing.Size(222, 32);
            this.textBoxPSWRD.TabIndex = 1;
            this.textBoxPSWRD.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(213, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "userName";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(208, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "password";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // BTNlogin
            // 
            this.BTNlogin.BackColor = System.Drawing.Color.Transparent;
            this.BTNlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNlogin.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BTNlogin.Location = new System.Drawing.Point(465, 293);
            this.BTNlogin.Name = "BTNlogin";
            this.BTNlogin.Size = new System.Drawing.Size(94, 37);
            this.BTNlogin.TabIndex = 4;
            this.BTNlogin.Text = "Login";
            this.BTNlogin.UseVisualStyleBackColor = false;
            this.BTNlogin.Click += new System.EventHandler(this.BTNlogin_Click);
            // 
            // BTNreset
            // 
            this.BTNreset.BackColor = System.Drawing.Color.Transparent;
            this.BTNreset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNreset.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BTNreset.Location = new System.Drawing.Point(337, 293);
            this.BTNreset.Name = "BTNreset";
            this.BTNreset.Size = new System.Drawing.Size(94, 37);
            this.BTNreset.TabIndex = 5;
            this.BTNreset.Text = "Reset";
            this.BTNreset.UseVisualStyleBackColor = false;
            this.BTNreset.Click += new System.EventHandler(this.BTNreset_Click);
            // 
            // BTNshowPswrd
            // 
            this.BTNshowPswrd.BackColor = System.Drawing.Color.Transparent;
            this.BTNshowPswrd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNshowPswrd.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BTNshowPswrd.Location = new System.Drawing.Point(581, 229);
            this.BTNshowPswrd.Name = "BTNshowPswrd";
            this.BTNshowPswrd.Size = new System.Drawing.Size(94, 29);
            this.BTNshowPswrd.TabIndex = 6;
            this.BTNshowPswrd.Text = "Show";
            this.BTNshowPswrd.UseVisualStyleBackColor = false;
            this.BTNshowPswrd.Click += new System.EventHandler(this.BTNshowPswrd_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(323, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(261, 60);
            this.label4.TabIndex = 8;
            this.label4.Text = "Welcome!";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::WinFormsApp2.Properties.Resources.Educational_ecosystem;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(195, 169);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WinFormsApp2.Properties.Resources.BP9vUl;
            this.ClientSize = new System.Drawing.Size(832, 433);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BTNshowPswrd);
            this.Controls.Add(this.BTNreset);
            this.Controls.Add(this.BTNlogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxPSWRD);
            this.Controls.Add(this.textBoxUserName);
            this.Name = "LoginForm";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBoxUserName;
        private TextBox textBoxPSWRD;
        private Label label1;
        private Label label2;
        private Button BTNlogin;
        private Button BTNreset;
        private Button BTNshowPswrd;
        private Label label4;
        private PictureBox pictureBox2;
    }
}