﻿using person;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class dashBoard : Form
    {
        public int totalPersons = 0;
        public int totalMales = 0;
        public int totalFemales = 0;
        public int totalLecturers=0;
        public int totalMaleLectures=0;
        public int totalFemaleLectures = 0;
        public int totalActiveStudens = 0;
        public double totalActiveStudensAge = 0;
        public double totalActiveStudensAvr= 0;
        public int totalActiveStudensMales= 0;
        public int totalActiveStudensFemales = 0;
        public int totalGraduatedStudens = 0;
        public double totalGraduatedStudensAvr = 0;
        public double totalGraduatedStudensAge = 0;
        public int totalGraduatedStudensMales = 0;
        public int totalGraduatedStudensFemales = 0;



        public List<Person> dashboardList = new List<Person>();
        public dashBoard()
        {
            InitializeComponent();
        }

        private void dashBoard_Load(object sender, EventArgs e)
        {
            totalPersonLBL.Text += totalPersons.ToString();
            personsMalesLbl.Text += totalMales.ToString();
            personsFemalesLbl.Text += totalFemales.ToString();
            TotalLecturersLbl.Text+= totalLecturers.ToString();
            lecturersMalesLbl.Text += totalMaleLectures.ToString();
            lecturersFemalesLbl.Text += totalFemaleLectures.ToString();
            activeStudentsLbl.Text += totalActiveStudens.ToString();
            activeStudentsMalesLbl.Text+= totalActiveStudensMales.ToString();
            activeStudentFemalesLbl.Text += totalActiveStudensFemales.ToString();
            activeStudentAvrLbl.Text += totalActiveStudensAvr.ToString();
            activeStudentAgeLbl.Text+= totalActiveStudensAge.ToString();
            graduateStudentsLbl.Text += totalGraduatedStudens.ToString();
            graduateStudentsMalesLb.Text+=totalGraduatedStudensMales.ToString();
            graduateStudentsFemalesLb.Text += totalGraduatedStudensFemales.ToString();
            graduateStudentsAgeLb.Text += totalGraduatedStudensAge.ToString();
            graduateStudentsAvrLb.Text += totalGraduatedStudensAvr.ToString();
        }

        private void totalPersonLBL_Click(object sender, EventArgs e)
        {

        }
    }
}
