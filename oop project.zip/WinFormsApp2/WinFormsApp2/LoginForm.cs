namespace WinFormsApp2
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BTNshowPswrd_Click(object sender, EventArgs e)
        {
            if (textBoxPSWRD.UseSystemPasswordChar == false)
                textBoxPSWRD.UseSystemPasswordChar = true;
            else
                textBoxPSWRD.UseSystemPasswordChar = false;
        }

        private void BTNreset_Click(object sender, EventArgs e)
        {
            textBoxPSWRD.Text = "";
            textBoxUserName.Text = "";
        }

        private void BTNlogin_Click(object sender, EventArgs e)
        {
            if(textBoxUserName.Text.Equals(textBoxPSWRD.Text) &&(textBoxUserName.Text !="" && textBoxPSWRD.Text!=""))
            {

                CollegeManagmentSystem c = new CollegeManagmentSystem();
                c.Show();
            }
            else
            {
                if((textBoxUserName.Text == "" || textBoxPSWRD.Text == ""))
                {
                    MessageBox.Show("Please fill all the fields!");
                }
                else if(!textBoxUserName.Text.Equals(textBoxPSWRD.Text))
                {
                    MessageBox.Show("Incorrect userName or Password!");
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}