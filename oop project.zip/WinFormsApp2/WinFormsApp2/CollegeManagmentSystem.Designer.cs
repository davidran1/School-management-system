﻿namespace WinFormsApp2
{
    partial class CollegeManagmentSystem: System.Windows.Forms.Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lecturersBox = new System.Windows.Forms.PictureBox();
            this.activeStudentBox = new System.Windows.Forms.PictureBox();
            this.graduatedStudentsBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.PersonTypeComboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.idLabel = new System.Windows.Forms.Label();
            this.ganderLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameTxtBox = new System.Windows.Forms.TextBox();
            this.lastNameTxtbox = new System.Windows.Forms.TextBox();
            this.idTxtBox = new System.Windows.Forms.TextBox();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.malePictureBox = new System.Windows.Forms.PictureBox();
            this.femalePictureBox = new System.Windows.Forms.PictureBox();
            this.dashboardBox = new System.Windows.Forms.PictureBox();
            this.yearEducationLabel = new System.Windows.Forms.Label();
            this.averageLabel = new System.Windows.Forms.Label();
            this.averageTxtBox = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.addButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.femaleSelectedButton = new System.Windows.Forms.RadioButton();
            this.maleSelectedButton = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.yearEducationTxtBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.lecturersBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.activeStudentBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.graduatedStudentsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.malePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.femalePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // lecturersBox
            // 
            this.lecturersBox.BackColor = System.Drawing.Color.Transparent;
            this.lecturersBox.Image = global::WinFormsApp2.Properties.Resources.lecturer_1_256;
            this.lecturersBox.Location = new System.Drawing.Point(21, 53);
            this.lecturersBox.Name = "lecturersBox";
            this.lecturersBox.Size = new System.Drawing.Size(125, 105);
            this.lecturersBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lecturersBox.TabIndex = 0;
            this.lecturersBox.TabStop = false;
            this.lecturersBox.Click += new System.EventHandler(this.lecturersBox_Click);
            // 
            // activeStudentBox
            // 
            this.activeStudentBox.BackColor = System.Drawing.Color.Transparent;
            this.activeStudentBox.Image = global::WinFormsApp2.Properties.Resources.active_student;
            this.activeStudentBox.Location = new System.Drawing.Point(21, 227);
            this.activeStudentBox.Name = "activeStudentBox";
            this.activeStudentBox.Size = new System.Drawing.Size(125, 107);
            this.activeStudentBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.activeStudentBox.TabIndex = 1;
            this.activeStudentBox.TabStop = false;
            this.activeStudentBox.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // graduatedStudentsBox
            // 
            this.graduatedStudentsBox.BackColor = System.Drawing.Color.Transparent;
            this.graduatedStudentsBox.Image = global::WinFormsApp2.Properties.Resources.graduate_64;
            this.graduatedStudentsBox.Location = new System.Drawing.Point(21, 393);
            this.graduatedStudentsBox.Name = "graduatedStudentsBox";
            this.graduatedStudentsBox.Size = new System.Drawing.Size(125, 112);
            this.graduatedStudentsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.graduatedStudentsBox.TabIndex = 2;
            this.graduatedStudentsBox.TabStop = false;
            this.graduatedStudentsBox.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(152, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(629, 53);
            this.label1.TabIndex = 3;
            this.label1.Text = "College Managment System";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::WinFormsApp2.Properties.Resources.logout_login_2561;
            this.pictureBox4.Location = new System.Drawing.Point(811, 660);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(61, 43);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // PersonTypeComboBox
            // 
            this.PersonTypeComboBox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PersonTypeComboBox.FormattingEnabled = true;
            this.PersonTypeComboBox.Items.AddRange(new object[] {
            "Choose..",
            "Lecturer",
            "Student"});
            this.PersonTypeComboBox.Location = new System.Drawing.Point(360, 100);
            this.PersonTypeComboBox.Name = "PersonTypeComboBox";
            this.PersonTypeComboBox.Size = new System.Drawing.Size(217, 28);
            this.PersonTypeComboBox.TabIndex = 5;
            this.PersonTypeComboBox.Text = "Choose..";
            this.PersonTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(219, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 26);
            this.label2.TabIndex = 6;
            this.label2.Text = "Add person";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.firstNameLabel.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.firstNameLabel.Location = new System.Drawing.Point(219, 189);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(92, 18);
            this.firstNameLabel.TabIndex = 7;
            this.firstNameLabel.Text = "first name";
            this.firstNameLabel.Visible = false;
            this.firstNameLabel.Click += new System.EventHandler(this.nameLabel_Click);
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.BackColor = System.Drawing.Color.Transparent;
            this.ageLabel.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ageLabel.Location = new System.Drawing.Point(517, 267);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(36, 18);
            this.ageLabel.TabIndex = 8;
            this.ageLabel.Text = "age";
            this.ageLabel.Visible = false;
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.BackColor = System.Drawing.Color.Transparent;
            this.idLabel.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.idLabel.Location = new System.Drawing.Point(219, 267);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(24, 18);
            this.idLabel.TabIndex = 9;
            this.idLabel.Text = "id";
            this.idLabel.Visible = false;
            // 
            // ganderLabel
            // 
            this.ganderLabel.AutoSize = true;
            this.ganderLabel.BackColor = System.Drawing.Color.Transparent;
            this.ganderLabel.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ganderLabel.Location = new System.Drawing.Point(219, 340);
            this.ganderLabel.Name = "ganderLabel";
            this.ganderLabel.Size = new System.Drawing.Size(91, 26);
            this.ganderLabel.TabIndex = 10;
            this.ganderLabel.Text = "gander";
            this.ganderLabel.Visible = false;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.lastNameLabel.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lastNameLabel.Location = new System.Drawing.Point(517, 189);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(86, 18);
            this.lastNameLabel.TabIndex = 11;
            this.lastNameLabel.Text = "last name";
            this.lastNameLabel.Visible = false;
            // 
            // firstNameTxtBox
            // 
            this.firstNameTxtBox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.firstNameTxtBox.Location = new System.Drawing.Point(329, 185);
            this.firstNameTxtBox.Name = "firstNameTxtBox";
            this.firstNameTxtBox.Size = new System.Drawing.Size(125, 32);
            this.firstNameTxtBox.TabIndex = 12;
            this.firstNameTxtBox.Visible = false;
            // 
            // lastNameTxtbox
            // 
            this.lastNameTxtbox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lastNameTxtbox.Location = new System.Drawing.Point(625, 185);
            this.lastNameTxtbox.Name = "lastNameTxtbox";
            this.lastNameTxtbox.Size = new System.Drawing.Size(125, 32);
            this.lastNameTxtbox.TabIndex = 13;
            this.lastNameTxtbox.Visible = false;
            // 
            // idTxtBox
            // 
            this.idTxtBox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.idTxtBox.Location = new System.Drawing.Point(329, 261);
            this.idTxtBox.Name = "idTxtBox";
            this.idTxtBox.Size = new System.Drawing.Size(125, 32);
            this.idTxtBox.TabIndex = 14;
            this.idTxtBox.Visible = false;
            // 
            // ageTextBox
            // 
            this.ageTextBox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ageTextBox.Location = new System.Drawing.Point(625, 267);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(125, 32);
            this.ageTextBox.TabIndex = 15;
            this.ageTextBox.Visible = false;
            this.ageTextBox.TextChanged += new System.EventHandler(this.ageTextBox_TextChanged);
            // 
            // malePictureBox
            // 
            this.malePictureBox.BackColor = System.Drawing.Color.Transparent;
            this.malePictureBox.BackgroundImage = global::WinFormsApp2.Properties.Resources.male_32_64;
            this.malePictureBox.Location = new System.Drawing.Point(343, 327);
            this.malePictureBox.Name = "malePictureBox";
            this.malePictureBox.Size = new System.Drawing.Size(62, 61);
            this.malePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.malePictureBox.TabIndex = 16;
            this.malePictureBox.TabStop = false;
            this.malePictureBox.Visible = false;
            // 
            // femalePictureBox
            // 
            this.femalePictureBox.BackColor = System.Drawing.Color.Transparent;
            this.femalePictureBox.BackgroundImage = global::WinFormsApp2.Properties.Resources.female_25_64;
            this.femalePictureBox.Location = new System.Drawing.Point(455, 327);
            this.femalePictureBox.Name = "femalePictureBox";
            this.femalePictureBox.Size = new System.Drawing.Size(59, 61);
            this.femalePictureBox.TabIndex = 17;
            this.femalePictureBox.TabStop = false;
            this.femalePictureBox.Visible = false;
            // 
            // dashboardBox
            // 
            this.dashboardBox.BackColor = System.Drawing.Color.Transparent;
            this.dashboardBox.Image = global::WinFormsApp2.Properties.Resources.stats_12_64;
            this.dashboardBox.Location = new System.Drawing.Point(21, 565);
            this.dashboardBox.Name = "dashboardBox";
            this.dashboardBox.Size = new System.Drawing.Size(106, 96);
            this.dashboardBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dashboardBox.TabIndex = 18;
            this.dashboardBox.TabStop = false;
            this.dashboardBox.Click += new System.EventHandler(this.dashboardBox_Click);
            // 
            // yearEducationLabel
            // 
            this.yearEducationLabel.AutoSize = true;
            this.yearEducationLabel.BackColor = System.Drawing.Color.Transparent;
            this.yearEducationLabel.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.yearEducationLabel.ForeColor = System.Drawing.Color.Black;
            this.yearEducationLabel.Location = new System.Drawing.Point(219, 451);
            this.yearEducationLabel.Name = "yearEducationLabel";
            this.yearEducationLabel.Size = new System.Drawing.Size(135, 18);
            this.yearEducationLabel.TabIndex = 19;
            this.yearEducationLabel.Text = "year/education";
            this.yearEducationLabel.Visible = false;
            // 
            // averageLabel
            // 
            this.averageLabel.AutoSize = true;
            this.averageLabel.BackColor = System.Drawing.Color.Transparent;
            this.averageLabel.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.averageLabel.Location = new System.Drawing.Point(503, 451);
            this.averageLabel.Name = "averageLabel";
            this.averageLabel.Size = new System.Drawing.Size(74, 18);
            this.averageLabel.TabIndex = 21;
            this.averageLabel.Text = "average";
            this.averageLabel.Visible = false;
            // 
            // averageTxtBox
            // 
            this.averageTxtBox.BackColor = System.Drawing.SystemColors.Window;
            this.averageTxtBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.averageTxtBox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.averageTxtBox.Location = new System.Drawing.Point(625, 440);
            this.averageTxtBox.Name = "averageTxtBox";
            this.averageTxtBox.Size = new System.Drawing.Size(125, 32);
            this.averageTxtBox.TabIndex = 24;
            this.averageTxtBox.Visible = false;
            this.averageTxtBox.TextChanged += new System.EventHandler(this.averageTxtBox_TextChanged);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = global::WinFormsApp2.Properties.Resources.save_28_256;
            this.pictureBox6.Location = new System.Drawing.Point(739, 660);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(66, 43);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 25;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.Transparent;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addButton.Location = new System.Drawing.Point(219, 581);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(94, 40);
            this.addButton.TabIndex = 26;
            this.addButton.Text = "add";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Visible = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.BackColor = System.Drawing.Color.Transparent;
            this.updateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateButton.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.updateButton.Location = new System.Drawing.Point(395, 581);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(166, 40);
            this.updateButton.TabIndex = 27;
            this.updateButton.Text = "update";
            this.updateButton.UseVisualStyleBackColor = false;
            this.updateButton.Visible = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.BackColor = System.Drawing.Color.Transparent;
            this.deleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteButton.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.deleteButton.Location = new System.Drawing.Point(625, 581);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(128, 40);
            this.deleteButton.TabIndex = 28;
            this.deleteButton.Text = "delete";
            this.deleteButton.UseVisualStyleBackColor = false;
            this.deleteButton.Visible = false;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(822, 644);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 29;
            this.label3.Text = "exit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(753, 644);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 17);
            this.label4.TabIndex = 30;
            this.label4.Text = "save";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::WinFormsApp2.Properties.Resources.load_file_64;
            this.pictureBox7.Location = new System.Drawing.Point(679, 660);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(54, 45);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 31;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(679, 644);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 17);
            this.label6.TabIndex = 33;
            this.label6.Text = "load";
            // 
            // femaleSelectedButton
            // 
            this.femaleSelectedButton.AutoSize = true;
            this.femaleSelectedButton.BackColor = System.Drawing.Color.Transparent;
            this.femaleSelectedButton.Location = new System.Drawing.Point(479, 397);
            this.femaleSelectedButton.Name = "femaleSelectedButton";
            this.femaleSelectedButton.Size = new System.Drawing.Size(17, 16);
            this.femaleSelectedButton.TabIndex = 34;
            this.femaleSelectedButton.TabStop = true;
            this.femaleSelectedButton.UseVisualStyleBackColor = false;
            this.femaleSelectedButton.Visible = false;
            // 
            // maleSelectedButton
            // 
            this.maleSelectedButton.AutoSize = true;
            this.maleSelectedButton.BackColor = System.Drawing.Color.Transparent;
            this.maleSelectedButton.Location = new System.Drawing.Point(360, 397);
            this.maleSelectedButton.Name = "maleSelectedButton";
            this.maleSelectedButton.Size = new System.Drawing.Size(17, 16);
            this.maleSelectedButton.TabIndex = 35;
            this.maleSelectedButton.TabStop = true;
            this.maleSelectedButton.UseVisualStyleBackColor = false;
            this.maleSelectedButton.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(21, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 18);
            this.label5.TabIndex = 36;
            this.label5.Text = "ACTIVE STUDENTS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(37, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 18);
            this.label7.TabIndex = 37;
            this.label7.Text = "LECTURERS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(11, 508);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(164, 18);
            this.label8.TabIndex = 38;
            this.label8.Text = "GRADUATE STUDENTS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(27, 664);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 18);
            this.label9.TabIndex = 39;
            this.label9.Text = "DASHBOARD";
            // 
            // yearEducationTxtBox
            // 
            this.yearEducationTxtBox.Font = new System.Drawing.Font("MV Boli", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.yearEducationTxtBox.FormattingEnabled = true;
            this.yearEducationTxtBox.Location = new System.Drawing.Point(329, 447);
            this.yearEducationTxtBox.Name = "yearEducationTxtBox";
            this.yearEducationTxtBox.Size = new System.Drawing.Size(151, 28);
            this.yearEducationTxtBox.TabIndex = 40;
            this.yearEducationTxtBox.Visible = false;
            // 
            // CollegeManagmentSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = global::WinFormsApp2.Properties.Resources.BP9vUl;
            this.ClientSize = new System.Drawing.Size(873, 707);
            this.Controls.Add(this.yearEducationTxtBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.maleSelectedButton);
            this.Controls.Add(this.femaleSelectedButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.averageTxtBox);
            this.Controls.Add(this.averageLabel);
            this.Controls.Add(this.yearEducationLabel);
            this.Controls.Add(this.dashboardBox);
            this.Controls.Add(this.femalePictureBox);
            this.Controls.Add(this.malePictureBox);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(this.idTxtBox);
            this.Controls.Add(this.lastNameTxtbox);
            this.Controls.Add(this.firstNameTxtBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.ganderLabel);
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PersonTypeComboBox);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.graduatedStudentsBox);
            this.Controls.Add(this.activeStudentBox);
            this.Controls.Add(this.lecturersBox);
            this.Name = "CollegeManagmentSystem";
            this.Text = "Management System";
            this.Load += new System.EventHandler(this.CollegeManagmentSystem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lecturersBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.activeStudentBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.graduatedStudentsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.malePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.femalePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox lecturersBox;
        private PictureBox activeStudentBox;
        private PictureBox graduatedStudentsBox;
        private Label label1;
        private ImageList imageList1;
        private ImageList imageList2;
        private PictureBox pictureBox4;
        private ComboBox PersonTypeComboBox;
        private Label label2;
        private Label firstNameLabel;
        private Label ageLabel;
        private Label idLabel;
        private Label ganderLabel;
        private Label lastNameLabel;
        private TextBox firstNameTxtBox;
        private TextBox lastNameTxtbox;
        private TextBox idTxtBox;
        private TextBox ageTextBox;
        private PictureBox malePictureBox;
        private PictureBox femalePictureBox;
        private PictureBox dashboardBox;
        private Label yearEducationLabel;
        private Label averageLabel;
        private TextBox averageTxtBox;
        private PictureBox pictureBox6;
        private Button addButton;
        private Button updateButton;
        private Button deleteButton;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox7;
        private Label label6;
        private RadioButton femaleSelectedButton;
        private RadioButton maleSelectedButton;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label9;
        private ComboBox yearEducationTxtBox;
    }
}