﻿namespace WinFormsApp2
{
    partial class dashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.personsFemalesLbl = new System.Windows.Forms.Label();
            this.personsMalesLbl = new System.Windows.Forms.Label();
            this.totalPersonLBL = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lecturersFemalesLbl = new System.Windows.Forms.Label();
            this.lecturersMalesLbl = new System.Windows.Forms.Label();
            this.TotalLecturersLbl = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.graduateStudentsAvrLb = new System.Windows.Forms.Label();
            this.graduateStudentsAgeLb = new System.Windows.Forms.Label();
            this.graduateStudentsFemalesLb = new System.Windows.Forms.Label();
            this.graduateStudentsMalesLb = new System.Windows.Forms.Label();
            this.graduateStudentsLbl = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.activeStudentAvrLbl = new System.Windows.Forms.Label();
            this.activeStudentAgeLbl = new System.Windows.Forms.Label();
            this.activeStudentFemalesLbl = new System.Windows.Forms.Label();
            this.activeStudentsMalesLbl = new System.Windows.Forms.Label();
            this.activeStudentsLbl = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label1.Location = new System.Drawing.Point(145, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "DashBoard";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.personsFemalesLbl);
            this.panel1.Controls.Add(this.personsMalesLbl);
            this.panel1.Controls.Add(this.totalPersonLBL);
            this.panel1.Location = new System.Drawing.Point(10, 73);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(217, 104);
            this.panel1.TabIndex = 1;
            // 
            // personsFemalesLbl
            // 
            this.personsFemalesLbl.AutoSize = true;
            this.personsFemalesLbl.BackColor = System.Drawing.Color.Transparent;
            this.personsFemalesLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.personsFemalesLbl.ForeColor = System.Drawing.Color.Teal;
            this.personsFemalesLbl.Location = new System.Drawing.Point(3, 74);
            this.personsFemalesLbl.Name = "personsFemalesLbl";
            this.personsFemalesLbl.Size = new System.Drawing.Size(63, 15);
            this.personsFemalesLbl.TabIndex = 2;
            this.personsFemalesLbl.Text = "Females:";
            // 
            // personsMalesLbl
            // 
            this.personsMalesLbl.AutoSize = true;
            this.personsMalesLbl.BackColor = System.Drawing.Color.Transparent;
            this.personsMalesLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.personsMalesLbl.ForeColor = System.Drawing.Color.Teal;
            this.personsMalesLbl.Location = new System.Drawing.Point(3, 41);
            this.personsMalesLbl.Name = "personsMalesLbl";
            this.personsMalesLbl.Size = new System.Drawing.Size(49, 15);
            this.personsMalesLbl.TabIndex = 1;
            this.personsMalesLbl.Text = "Males:";
            // 
            // totalPersonLBL
            // 
            this.totalPersonLBL.AutoSize = true;
            this.totalPersonLBL.BackColor = System.Drawing.Color.Transparent;
            this.totalPersonLBL.Font = new System.Drawing.Font("Showcard Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.totalPersonLBL.ForeColor = System.Drawing.Color.DarkCyan;
            this.totalPersonLBL.Location = new System.Drawing.Point(3, 10);
            this.totalPersonLBL.Name = "totalPersonLBL";
            this.totalPersonLBL.Size = new System.Drawing.Size(122, 18);
            this.totalPersonLBL.TabIndex = 0;
            this.totalPersonLBL.Text = "Total persons:";
            this.totalPersonLBL.Click += new System.EventHandler(this.totalPersonLBL_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.AliceBlue;
            this.panel2.Controls.Add(this.lecturersFemalesLbl);
            this.panel2.Controls.Add(this.lecturersMalesLbl);
            this.panel2.Controls.Add(this.TotalLecturersLbl);
            this.panel2.Location = new System.Drawing.Point(277, 73);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 104);
            this.panel2.TabIndex = 2;
            // 
            // lecturersFemalesLbl
            // 
            this.lecturersFemalesLbl.AutoSize = true;
            this.lecturersFemalesLbl.BackColor = System.Drawing.Color.Transparent;
            this.lecturersFemalesLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lecturersFemalesLbl.ForeColor = System.Drawing.Color.Teal;
            this.lecturersFemalesLbl.Location = new System.Drawing.Point(3, 74);
            this.lecturersFemalesLbl.Name = "lecturersFemalesLbl";
            this.lecturersFemalesLbl.Size = new System.Drawing.Size(63, 15);
            this.lecturersFemalesLbl.TabIndex = 2;
            this.lecturersFemalesLbl.Text = "Females:";
            // 
            // lecturersMalesLbl
            // 
            this.lecturersMalesLbl.AutoSize = true;
            this.lecturersMalesLbl.BackColor = System.Drawing.Color.Transparent;
            this.lecturersMalesLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lecturersMalesLbl.ForeColor = System.Drawing.Color.Teal;
            this.lecturersMalesLbl.Location = new System.Drawing.Point(3, 41);
            this.lecturersMalesLbl.Name = "lecturersMalesLbl";
            this.lecturersMalesLbl.Size = new System.Drawing.Size(49, 15);
            this.lecturersMalesLbl.TabIndex = 1;
            this.lecturersMalesLbl.Text = "Males:";
            // 
            // TotalLecturersLbl
            // 
            this.TotalLecturersLbl.AutoSize = true;
            this.TotalLecturersLbl.BackColor = System.Drawing.Color.Transparent;
            this.TotalLecturersLbl.Font = new System.Drawing.Font("Showcard Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TotalLecturersLbl.ForeColor = System.Drawing.Color.DarkCyan;
            this.TotalLecturersLbl.Location = new System.Drawing.Point(3, 10);
            this.TotalLecturersLbl.Name = "TotalLecturersLbl";
            this.TotalLecturersLbl.Size = new System.Drawing.Size(138, 18);
            this.TotalLecturersLbl.TabIndex = 0;
            this.TotalLecturersLbl.Text = "Total LECTURERs:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.AliceBlue;
            this.panel3.Controls.Add(this.graduateStudentsAvrLb);
            this.panel3.Controls.Add(this.graduateStudentsAgeLb);
            this.panel3.Controls.Add(this.graduateStudentsFemalesLb);
            this.panel3.Controls.Add(this.graduateStudentsMalesLb);
            this.panel3.Controls.Add(this.graduateStudentsLbl);
            this.panel3.Location = new System.Drawing.Point(277, 230);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(241, 147);
            this.panel3.TabIndex = 3;
            // 
            // graduateStudentsAvrLb
            // 
            this.graduateStudentsAvrLb.AutoSize = true;
            this.graduateStudentsAvrLb.BackColor = System.Drawing.Color.Transparent;
            this.graduateStudentsAvrLb.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.graduateStudentsAvrLb.ForeColor = System.Drawing.Color.Teal;
            this.graduateStudentsAvrLb.Location = new System.Drawing.Point(3, 127);
            this.graduateStudentsAvrLb.Name = "graduateStudentsAvrLb";
            this.graduateStudentsAvrLb.Size = new System.Drawing.Size(83, 15);
            this.graduateStudentsAvrLb.TabIndex = 5;
            this.graduateStudentsAvrLb.Text = "GRADES AVR:";
            // 
            // graduateStudentsAgeLb
            // 
            this.graduateStudentsAgeLb.AutoSize = true;
            this.graduateStudentsAgeLb.BackColor = System.Drawing.Color.Transparent;
            this.graduateStudentsAgeLb.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.graduateStudentsAgeLb.ForeColor = System.Drawing.Color.Teal;
            this.graduateStudentsAgeLb.Location = new System.Drawing.Point(3, 100);
            this.graduateStudentsAgeLb.Name = "graduateStudentsAgeLb";
            this.graduateStudentsAgeLb.Size = new System.Drawing.Size(87, 15);
            this.graduateStudentsAgeLb.TabIndex = 4;
            this.graduateStudentsAgeLb.Text = "AGE AVERAGE:";
            // 
            // graduateStudentsFemalesLb
            // 
            this.graduateStudentsFemalesLb.AutoSize = true;
            this.graduateStudentsFemalesLb.BackColor = System.Drawing.Color.Transparent;
            this.graduateStudentsFemalesLb.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.graduateStudentsFemalesLb.ForeColor = System.Drawing.Color.Teal;
            this.graduateStudentsFemalesLb.Location = new System.Drawing.Point(3, 74);
            this.graduateStudentsFemalesLb.Name = "graduateStudentsFemalesLb";
            this.graduateStudentsFemalesLb.Size = new System.Drawing.Size(63, 15);
            this.graduateStudentsFemalesLb.TabIndex = 2;
            this.graduateStudentsFemalesLb.Text = "Females:";
            // 
            // graduateStudentsMalesLb
            // 
            this.graduateStudentsMalesLb.AutoSize = true;
            this.graduateStudentsMalesLb.BackColor = System.Drawing.Color.Transparent;
            this.graduateStudentsMalesLb.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.graduateStudentsMalesLb.ForeColor = System.Drawing.Color.Teal;
            this.graduateStudentsMalesLb.Location = new System.Drawing.Point(3, 41);
            this.graduateStudentsMalesLb.Name = "graduateStudentsMalesLb";
            this.graduateStudentsMalesLb.Size = new System.Drawing.Size(49, 15);
            this.graduateStudentsMalesLb.TabIndex = 1;
            this.graduateStudentsMalesLb.Text = "Males:";
            // 
            // graduateStudentsLbl
            // 
            this.graduateStudentsLbl.AutoSize = true;
            this.graduateStudentsLbl.BackColor = System.Drawing.Color.Transparent;
            this.graduateStudentsLbl.Font = new System.Drawing.Font("Showcard Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.graduateStudentsLbl.ForeColor = System.Drawing.Color.DarkCyan;
            this.graduateStudentsLbl.Location = new System.Drawing.Point(3, 10);
            this.graduateStudentsLbl.Name = "graduateStudentsLbl";
            this.graduateStudentsLbl.Size = new System.Drawing.Size(230, 18);
            this.graduateStudentsLbl.TabIndex = 0;
            this.graduateStudentsLbl.Text = "Total graduated STUDENTSs:";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.AliceBlue;
            this.panel4.Controls.Add(this.activeStudentAvrLbl);
            this.panel4.Controls.Add(this.activeStudentAgeLbl);
            this.panel4.Controls.Add(this.activeStudentFemalesLbl);
            this.panel4.Controls.Add(this.activeStudentsMalesLbl);
            this.panel4.Controls.Add(this.activeStudentsLbl);
            this.panel4.Location = new System.Drawing.Point(13, 230);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(214, 147);
            this.panel4.TabIndex = 4;
            // 
            // activeStudentAvrLbl
            // 
            this.activeStudentAvrLbl.AutoSize = true;
            this.activeStudentAvrLbl.BackColor = System.Drawing.Color.Transparent;
            this.activeStudentAvrLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.activeStudentAvrLbl.ForeColor = System.Drawing.Color.Teal;
            this.activeStudentAvrLbl.Location = new System.Drawing.Point(3, 127);
            this.activeStudentAvrLbl.Name = "activeStudentAvrLbl";
            this.activeStudentAvrLbl.Size = new System.Drawing.Size(83, 15);
            this.activeStudentAvrLbl.TabIndex = 4;
            this.activeStudentAvrLbl.Text = "GRADES AVR:";
            // 
            // activeStudentAgeLbl
            // 
            this.activeStudentAgeLbl.AutoSize = true;
            this.activeStudentAgeLbl.BackColor = System.Drawing.Color.Transparent;
            this.activeStudentAgeLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.activeStudentAgeLbl.ForeColor = System.Drawing.Color.Teal;
            this.activeStudentAgeLbl.Location = new System.Drawing.Point(4, 100);
            this.activeStudentAgeLbl.Name = "activeStudentAgeLbl";
            this.activeStudentAgeLbl.Size = new System.Drawing.Size(87, 15);
            this.activeStudentAgeLbl.TabIndex = 3;
            this.activeStudentAgeLbl.Text = "AGE AVERAGE:";
            // 
            // activeStudentFemalesLbl
            // 
            this.activeStudentFemalesLbl.AutoSize = true;
            this.activeStudentFemalesLbl.BackColor = System.Drawing.Color.Transparent;
            this.activeStudentFemalesLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.activeStudentFemalesLbl.ForeColor = System.Drawing.Color.Teal;
            this.activeStudentFemalesLbl.Location = new System.Drawing.Point(3, 74);
            this.activeStudentFemalesLbl.Name = "activeStudentFemalesLbl";
            this.activeStudentFemalesLbl.Size = new System.Drawing.Size(63, 15);
            this.activeStudentFemalesLbl.TabIndex = 2;
            this.activeStudentFemalesLbl.Text = "Females:";
            // 
            // activeStudentsMalesLbl
            // 
            this.activeStudentsMalesLbl.AutoSize = true;
            this.activeStudentsMalesLbl.BackColor = System.Drawing.Color.Transparent;
            this.activeStudentsMalesLbl.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.activeStudentsMalesLbl.ForeColor = System.Drawing.Color.Teal;
            this.activeStudentsMalesLbl.Location = new System.Drawing.Point(3, 41);
            this.activeStudentsMalesLbl.Name = "activeStudentsMalesLbl";
            this.activeStudentsMalesLbl.Size = new System.Drawing.Size(49, 15);
            this.activeStudentsMalesLbl.TabIndex = 1;
            this.activeStudentsMalesLbl.Text = "Males:";
            // 
            // activeStudentsLbl
            // 
            this.activeStudentsLbl.AutoSize = true;
            this.activeStudentsLbl.BackColor = System.Drawing.Color.Transparent;
            this.activeStudentsLbl.Font = new System.Drawing.Font("Showcard Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.activeStudentsLbl.ForeColor = System.Drawing.Color.DarkCyan;
            this.activeStudentsLbl.Location = new System.Drawing.Point(3, 10);
            this.activeStudentsLbl.Name = "activeStudentsLbl";
            this.activeStudentsLbl.Size = new System.Drawing.Size(192, 18);
            this.activeStudentsLbl.TabIndex = 0;
            this.activeStudentsLbl.Text = "Total ACTIVE STUDENTSs:";
            // 
            // dashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::WinFormsApp2.Properties.Resources.BP9vUl;
            this.ClientSize = new System.Drawing.Size(542, 386);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "dashBoard";
            this.Text = "dashBoard";
            this.Load += new System.EventHandler(this.dashBoard_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Label personsFemalesLbl;
        private Label personsMalesLbl;
        private Label totalPersonLBL;
        private Panel panel2;
        private Label lecturersFemalesLbl;
        private Label lecturersMalesLbl;
        private Label TotalLecturersLbl;
        private Panel panel3;
        private Label graduateStudentsAvrLb;
        private Label graduateStudentsAgeLb;
        private Label graduateStudentsFemalesLb;
        private Label graduateStudentsMalesLb;
        private Label graduateStudentsLbl;
        private Panel panel4;
        private Label activeStudentAvrLbl;
        private Label activeStudentAgeLbl;
        private Label activeStudentFemalesLbl;
        private Label activeStudentsMalesLbl;
        private Label activeStudentsLbl;
    }
}