﻿using person;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class activeStudentsData : Form
    {
        public List<ActiveStudent>activeStudentsList= new List<ActiveStudent>();

        public activeStudentsData()
        {
            InitializeComponent();
        }
        private void activeStudentsDatacs_Load(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Id", typeof(string));
            table.Columns.Add("Age",typeof(int));
            table.Columns.Add("Year",typeof(int));
            table.Columns.Add("Average", typeof(double));  
            for(int i=0;i<activeStudentsList.Count;i++)
            {
                ActiveStudent a = (ActiveStudent)activeStudentsList[i];
                table.Rows.Add(activeStudentsList[i].getName(), activeStudentsList[i].getId(), activeStudentsList[i].getAge(), activeStudentsList[i].getCurrYear(), activeStudentsList[i].getCurrAvr());
            }
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
